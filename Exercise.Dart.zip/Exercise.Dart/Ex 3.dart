class Person {
  String name;
  int age;

  Person(this.name, this.age);
}

void main() {
  List<Person> people = [
    Person("Alice", 25),
    Person("Bob", 30),
    Person("Charlie", 35),
    Person("Anna", 22),
    Person("Ben", 28),
  ];

  // Step 1: Filter names starting with A or B
  var filtered = people.where((p) =>
      p.name.startsWith('A') || p.name.startsWith('B'));

  // Step 2: Extract ages
  var ages = filtered.map((p) => p.age);

  // Step 3: Calculate average
  double average = ages.reduce((a, b) => a + b) / ages.length;

  // Step 4: Print result rounded to 1 decimal
  print("Average age: ${average.toStringAsFixed(1)}");
}