import 'dart:io';

class Student {
  String name;
  double score;

  Student(this.name, this.score);

  String calculateGrade() {
    if (score >= 70) {
      return "A";
    } else if (score >= 60) {
      return "B";
    } else if (score >= 50) {
      return "C";
    } else if (score >= 45) {
      return "D";
    } else {
      return "F";
    }
  }
}

class GradeCalculator {
  List<Student> students = [];

  void addStudent(String name, double score) {
    students.add(Student(name, score));
  }

  double calculateAverage() {
    double total = 0;

    for (var student in students) {
      total += student.score;
    }

    return students.isEmpty ? 0 : total / students.length;
  }

  void displayResults() {
    print("\n------ Student Results ------");

    for (var student in students) {
      print(
          "Name: ${student.name} | Score: ${student.score} | Grade: ${student.calculateGrade()}");
    }
  }
}

void main() {
  GradeCalculator calculator = GradeCalculator();

  stdout.write("Enter number of students: ");
  int count = int.parse(stdin.readLineSync()!);

  for (int i = 0; i < count; i++) {
    stdout.write("\nEnter student name: ");
    String name = stdin.readLineSync()!;

    stdout.write("Enter student score: ");
    double score = double.parse(stdin.readLineSync()!);

    calculator.addStudent(name, score);
  }

  calculator.displayResults();

  double avg = calculator.calculateAverage();
  print("\nClass Average: ${avg.toStringAsFixed(2)}");
}