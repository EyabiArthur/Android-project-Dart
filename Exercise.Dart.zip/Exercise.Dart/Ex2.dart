void main() {
  List<String> words = ["apple", "cat", "banana", "dog", "elephant"];

  // Step 1: Create a map with word as key and length as value
  Map<String, int> wordLengthMap = {
    for (var word in words) word: word.length
  };

  // Step 2: Filter entries where length > 4
  var filtered = wordLengthMap.entries.where((entry) => entry.value > 4);

  // Step 3: Print the result
  for (var entry in filtered) {
    print("${entry.key} has length ${entry.value}");
  }
}